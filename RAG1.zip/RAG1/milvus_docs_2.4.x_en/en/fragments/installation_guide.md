This topic describes how to install Milvus standalone using Docker Compose, Kubernetes, or APT/YUM.

If you run into image loading errors while installing, you can [Install Milvus Offline](install_offline-docker.md).

You can also build Milvus from source code at [GitHub](https://github.com/milvus-io/milvus#to-start-developing-milvus).
