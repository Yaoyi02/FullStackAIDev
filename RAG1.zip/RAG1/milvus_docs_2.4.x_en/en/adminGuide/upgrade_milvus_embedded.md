---
id: upgrade_milvus_embedded.md
related_key: upgrade Embedded Milvus
summary: Learn how to upgrade embedded Milvus.
title: Upgrade Embedded Milvus
deprecate: true
---

# Upgrade Embedded Milvus