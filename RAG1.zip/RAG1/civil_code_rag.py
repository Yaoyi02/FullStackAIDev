import streamlit as st
import re
import numpy as np
import requests
from sentence_transformers import SentenceTransformer
import faiss

# -------------------------- 1. 文档分割（加载并处理民法典） --------------------------
def split_civil_code(file_path="mfd.md"):
    """分割民法典文档，按条款提取内容"""
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            content = file.read()
        
        # 按"**第X条**"格式分割条款（支持中文数字和阿拉伯数字）
        pattern = r'(\*\*第[零一二三四五六七八九十百千\d]+条\*\*)'
        sections = re.split(pattern, content)
        
        # 组合条款标题和内容
        articles = []
        for i in range(1, len(sections), 2):
            title = sections[i].strip()  # 条款标题（如"**第一条**"）
            content = sections[i+1].strip() if (i+1 < len(sections)) else ""  # 条款内容
            if title:
                articles.append(f"{title}\n{content}")
        
        st.success(f"✅ 成功加载《民法典》，共提取 {len(articles)} 条条款")
        return articles
    except FileNotFoundError:
        st.error(f"❌ 未找到文件：{file_path}，请确保mfd.md在当前目录")
        return []
    except Exception as e:
        st.error(f"❌ 文档分割失败：{str(e)}")
        return []

# -------------------------- 2. 向量存储（Faiss） --------------------------
class FaissVectorStore:
    def __init__(self):
        self.index = None
        self.texts = []  # 存储条款文本
        self.collection_exists = False

    def create_collection(self, dimension):
        """创建向量索引（内积距离，适合文本相似度计算）"""
        self.index = faiss.IndexFlatIP(dimension)
        self.collection_exists = True

    def insert(self, vectors, texts):
        """插入向量和对应文本"""
        if not self.collection_exists:
            raise ValueError("请先调用create_collection创建集合")
        vectors = np.array(vectors, dtype=np.float32)
        self.index.add(vectors)
        self.texts.extend(texts)

    def search(self, query_vector, top_k=3):
        """检索相似向量"""
        if not self.collection_exists:
            raise ValueError("请先创建集合并插入数据")
        query_vector = np.array([query_vector], dtype=np.float32)
        distances, indices = self.index.search(query_vector, top_k)
        # 返回(文本, 相似度)列表
        return [(self.texts[i], round(float(distances[0][idx]), 4)) 
                for idx, i in enumerate(indices[0]) if i < len(self.texts)]

# -------------------------- 3. 初始化核心组件 --------------------------
@st.cache_resource  # Streamlit缓存，避免重复加载模型和数据
def init_components():
    # 加载文档
    articles = split_civil_code()
    if not articles:
        return None, None, None
    
    # 加载嵌入模型（中文文本专用）
    embedding_model = SentenceTransformer("shibing624/text2vec-base-chinese")
    
    # 生成文档向量
    article_embeddings = embedding_model.encode(articles)
    
    # 初始化向量存储
    vector_store = FaissVectorStore()
    vector_store.create_collection(dimension=article_embeddings.shape[1])
    vector_store.insert(article_embeddings, articles)
    
    return embedding_model, vector_store, articles

# 初始化模型、向量存储和文档
embedding_model, vector_store, articles = init_components()

# -------------------------- 4. DeepSeek API调用（基于requests） --------------------------
def call_deepseek(question, context):
    """调用DeepSeek API生成回答"""
    API_KEY = "sk-aad29a173cf541a79e4a54f8ce153c8c"  # 替换为你的API Key
    API_URL = "https://api.deepseek.com/v1/chat/completions"
    
    # 系统提示
    system_prompt = """你是专业法律助手，仅依据提供的《民法典》条款回答问题，禁止编造内容。
    回答需引用具体条款（如"**第一条**"），若信息不足，直接说明"根据提供的内容无法回答"。"""
    
    # 构建用户提示
    user_prompt = f"""<context>\n{context}\n</context>\n<question>\n{question}\n</question>"""
    
    # 发送请求
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.1  # 低温度保证回答稳定
    }
    
    try:
        response = requests.post(API_URL, headers=headers, json=payload)
        response.raise_for_status()  # 抛出HTTP错误
        return response.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"❌ API调用失败：{str(e)}"

# -------------------------- 5. 问答主函数 --------------------------
def civil_code_qa(question):
    """民法典问答主流程"""
    if not all([embedding_model, vector_store]):
        return {"error": "初始化失败，无法处理请求"}
    
    # 检索相似条款
    query_embedding = embedding_model.encode([question])[0]
    similar_articles = vector_store.search(query_embedding, top_k=3)
    
    # 拼接上下文
    context = "\n\n".join([doc for doc, _ in similar_articles])
    
    # 调用大模型生成回答
    answer = call_deepseek(question, context)
    
    return {
        "question": question,
        "retrieved": similar_articles,  # 检索到的条款(文本, 相似度)
        "answer": answer
    }

# -------------------------- 6. Streamlit页面 --------------------------
st.title("📜 民法典RAG问答助手")
st.caption("基于向量检索的智能问答，精准引用民法典条款")

# 用户输入
question = st.text_input("请输入你的问题（例如：隐私权如何保护？）", placeholder="请输入问题...")

# 提交按钮
if st.button("获取答案", type="primary"):
    if not question.strip():
        st.warning("请输入问题后再查询")
    else:
        with st.spinner("正在检索条款并生成回答..."):
            result = civil_code_qa(question)
            
            if "error" in result:
                st.error(result["error"])
            else:
                # 展示问题
                st.subheader("你的问题")
                st.write(result["question"])
                
                # 展示检索到的条款
                st.subheader("📌 相关条款（相似度排序）")
                for i, (doc, score) in enumerate(result["retrieved"], 1):
                    with st.expander(f"条款{i}（相似度：{score}）", expanded=False):
                        st.write(doc)
                
                # 展示回答
                st.subheader("💡 AI回答")
                st.write(result["answer"])

# 页脚信息
st.divider()
st.caption("提示：确保mfd.md文件与本程序在同一目录，且包含完整的《民法典》内容")
    